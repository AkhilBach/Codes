%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%----------------------- BER graph for coding gain -----------------------%
%----------------------------- July 02, 2019 -----------------------------%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc;
clear variables;
close all;
tic

N=1e5;
snr=0:1:20;

n=7;
Nbits=4;

% P = randi([0,1],Nbits,n-Nbits);   
P=[1 1 0;0 1 1;1 1 1;1 0 1];         % Parity check matrix

pr1=zeros(1,length(snr));
pr2=zeros(1,length(snr));
for index=1:length(snr) %SNR
    snr(index)
    snrlinear=10^(snr(index)/10);
    sd=sqrt(1/snrlinear);
    
    er1=zeros(1,N/Nbits);
    er2=zeros(1,N/Nbits);
    for i=1:N/Nbits     %loop
        s=randi([0,1],1,Nbits);    %message bits 
    
    % without coding
        noise = randn(1,Nbits);
        y = (2*s-1) + sd*noise;
        x_det = y>0;
              
        
    % with coding
        encoded=my_lbc_encode(n,Nbits,s,P);    % encoded bits used for transmission
        txd=2*encoded-1;    %BPSK
       
        for j=1:length(encoded)   %number of bits
            noise = randn(1,n);
            transmitted = txd + sd*noise;
            tx = transmitted>0;
            received=my_lbc_decode(tx,P);
        end
        
      er1(i) = sum(s~=x_det);
      er2(i) = sum(s~=received(1,1:4));
    end
    pr1(index)=sum(er1)/N;
    pr2(index)=sum(er2)/N;
end

semilogy(snr,pr1,'-o',snr,pr2,'-p');
grid on
legend('Without coding','With LBC coding');
axis([ -0.5 14  0.5*1e-6 0.2])
% axis auto
xlabel('SNR (dB)');  ylabel('BER');
title('Coding gain');
toc