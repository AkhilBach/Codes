function CW=my_lbc_encode(n,k,a,P)
    m=n-k;

    Ik=eye(k);
    G=[Ik P];
    CW=mod(a*G,2);
end