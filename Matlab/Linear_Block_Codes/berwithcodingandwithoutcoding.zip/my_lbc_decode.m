function R = my_lbc_decode(tx,P)
    R = tx;
    n=7;
    Im=eye(3);
%     P=[1 1 0;0 1 1;1 1 1;1 0 1];
    H=[transpose(P) Im];
    HT=transpose(H);    %7x3
    S=mod(R*HT,2);      %1x3
    E=eye(n);           %7x7
    for i=1:n
        y = E(i,:)*HT;  %1x3
        z(i,:)=y;       %1x3
%     end    
%     for j=1:1:n
        if z(i,:) == S
            R(1,i)=1-R(1,i);
            Y=R(1,i);
        break;
        end
    end   

end